import os

print("Starting")
while True:
	os.system("cd \"C:\Program Files (x86)\WinSCP\" & WinSCP.com /script=\"C:\\EagleEye\\EdgeServer//connection.txt\"")
#os.system("open sftp://pi:harmit1@pi@raspberrypi/ -hostkey=\"\"")

