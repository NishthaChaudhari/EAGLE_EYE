#!/bin/bash
cmd /k 
cd C:\Program Files (x86)\WinSCP
WinSCP.com